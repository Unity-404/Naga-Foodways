# Naga Foodways — Figma Practice Assets

This pack contains the reusable visual assets from the Naga Foodways interface.
All SVG files can be dragged directly into Figma and ungrouped for practice.

## Contents

- `naga-foodways-asset-board.svg` — complete editable board for a new Figma page
- `brand-lockup.svg` — full Naga Foodways header logo
- `brand-mark.svg` — standalone geometric brand motif
- `weave-pattern.svg` — seamless 20 × 20 px pattern tile
- `heritage-guardian-badge.svg` — stewardship badge
- `icon-sheet.svg` — interface icon set in the app's square-stroke style
- `color-swatches.svg` — importable palette reference
- `DESIGN-TOKENS.md` — colors, typography, borders, and spacing notes
- `PHOTOGRAPHY.md` — source links and photographer credits for every image

## Figma import

1. Create a blank Figma file.
2. Drag `naga-foodways-asset-board.svg` onto the canvas.
3. Right-click the imported board and choose **Ungroup** repeatedly to edit its
   individual shapes and text.
4. Create local color styles from the swatches in `color-swatches.svg`.
5. Install or select **Libre Caslon Display** and **DM Sans** from Google Fonts.
6. Use `weave-pattern.svg` as a tiled image fill rather than stretching it.

## Visual rules

- Keep edges sharp: no corner radius, gradients, or soft shadows.
- Primary borders are 2 px black.
- Display headings use Libre Caslon Display.
- Interface text uses DM Sans.
- Yellow is reserved for origin tags, warnings, and cultural stewardship.
- Red indicates primary actions, active states, and archive indexing.

The geometric motif in this pack is an original interface asset created for this
project. It is a contemporary brand marker, not a reproduction of a sacred or
tribe-specific cultural symbol.
