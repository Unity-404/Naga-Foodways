# Photography sources

The app uses documentary-style food photography from Unsplash. Open a link,
download the original image from its photographer page, and place it in Figma.
Keep the photographer attribution when using the image outside private practice.

| App use | Photographer | Source |
| --- | --- | --- |
| Hero / food on banana leaves | You Le | https://unsplash.com/photos/79a52195d388 |
| Akibeye / cooked meat | Eiliv Aceron | https://unsplash.com/photos/1c93c61a1083 |
| Galho / bowl | Eiliv Aceron | https://unsplash.com/photos/31fe7d2cab4a |
| Anishi Aon / rustic meat | VK bro | https://unsplash.com/photos/855b8675edd7 |
| Axone chutney / plated food | Prasongsom Punyauppa-path | https://unsplash.com/photos/65a7848e1c76 |
| Bastenga / bowl of food | Naveen Varghese | https://unsplash.com/photos/c9f98e5363df |
| Hinkejvu / garden greens | Quang Nguyen Vinh | https://unsplash.com/photos/776b73513a6e |

## Image treatment

- Recipe cards: 4:3 crop, center or center-low focal point
- Hero: approximately 5:4 crop on desktop and portrait crop on mobile
- Saturation: about 82%
- Contrast: about 108%
- Do not add gradient overlays; use a flat black transparency only where text
  needs contrast.
