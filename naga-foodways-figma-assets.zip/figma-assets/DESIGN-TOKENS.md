# Design tokens

## Color

| Name | Hex | Primary use |
| --- | --- | --- |
| Hearth Red | `#B91C1C` | Brand, active filters, cultural indexing |
| Action Red | `#DC2626` | Primary actions |
| Midnight | `#0A0A0A` | Canvas, text, hard borders |
| Charcoal | `#18181B` | Secondary dark surfaces |
| Pure White | `#FFFFFF` | Cards and reversed text |
| Archive Paper | `#FAFAFA` | Main page canvas |
| Ochre | `#EAB308` | Secondary heritage accent |
| Hearth Yellow | `#FACC15` | Tags, ratings, warnings, stewardship |
| Rule Gray | `#D4D4D4` | Dividers and inactive controls |

## Typography

- Display: **Libre Caslon Display**, Regular
- Interface/body: **DM Sans**, Regular / Medium / Bold
- Large display headings: 52–98 px, line-height 90%, tracking -5%
- Section headings: 38–62 px, line-height 105%, tracking -4%
- Body: 13–17 px, line-height 155–190%
- Eyebrows: 10–11 px, Bold, uppercase, tracking 13–17%

## Construction

- Base spacing unit: 4 px
- Common spacing: 8, 12, 16, 24, 32, 48, 64 px
- Primary border: 2 px solid Midnight
- Fine rule: 1 px solid Rule Gray
- Components use square corners
- Icons use 24 × 24 px frames and 2 px square-ended strokes
